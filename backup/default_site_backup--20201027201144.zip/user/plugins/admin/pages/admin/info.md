---
title: PHP Info
template: config
expires: 0

access:
    admin.settings: true
    admin.super: true
---
